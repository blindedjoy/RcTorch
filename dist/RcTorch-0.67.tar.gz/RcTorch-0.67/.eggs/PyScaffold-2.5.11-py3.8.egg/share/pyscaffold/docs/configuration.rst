.. _configuration:

=============
Configuration
=============

Projects set up with PyScaffold feature an easy package configuration with
``setup.cfg``. Check out the example below as well as `pbr's usage manual
<http://docs.openstack.org/developer/pbr/#usage>`_.

.. literalinclude:: ./example_setup.cfg
