=======
License
=======

.. literalinclude:: ../LICENSE.txt
